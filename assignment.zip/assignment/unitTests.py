import unittest
import builtins
users = {'user1':'123'}

def delete():
    print("Enter user name to delete")
    user = input()
    del users[user]
    print("User deleted Successfully")


def helpCmd():
    return "Press 1 for creating new user \n Press 2 to update user \n Press 3 to delete user \n Press 4 to print all users \n Press 5 for weather information \n --help for help command"

class TestMethods(unittest.TestCase):

    def testhelp(self):
        self.assertEqual(helpCmd(), "Press 1 for creating new user \n Press 2 to update user \n Press 3 to delete user \n Press 4 to print all users \n Press 5 for weather information \n --help for help command")

    def testReadUsers(self):
        original_input = builtins.input
        builtins.input = lambda: 'user1'
        delete()
        self.assertEqual(users,{})

if __name__ == '__main__':
    unittest.main()