from cryptography.fernet import Fernet
users = {}
weatherInformation= {"goa":{"humidity":5,"Pressure":6,"Average Temperature":30,"Wind Speed":5,"Wind Degree":9,"UI index":12},"jaipur":{"humidity":5,"Pressure":6,"Average Temperature":30,"Wind Speed":5,"Wind Degree":9,"UI index":12},"banglore":{"humidity":5,"Pressure":6,"Average Temperature":30,"Wind Speed":5,"Wind Degree":9,"UI index":12},"-90/+90":{"humidity":5,"Pressure":6,"Average Temperature":30,"Wind Speed":5,"Wind Degree":9,"UI index":12}}
key = Fernet.generate_key()
cipherSuite = Fernet(key)
def create():
    print("enter user name:")
    user = input()
    print("enter password:")
    password = input()
    users[user]=cipherSuite.encrypt(password.encode())
    
def update():
    print("Enter your userName to update")
    user = input()
    password = users[user]
    print("Do you want to update username? y/n")
    ans = input()
    if(ans == "y"):
        print("Enter new userName")
        enteredUser = input()
        print("Enter your password")
        i =3
        p=0
        while(i!=0):
            enteredPass = input()
            if(cipherSuite.decrypt(password).decode()==enteredPass):
                del users[user]
                users[enteredUser] = password
                print("Username updated successfully")
                p=1
                break
            else:
                print("incorrect password")
            i-=1
        if(p!=1):
            print("Incorrect password attemp 3 times.Please try again later.")
    print("Do you want to update password? y/n")
    ans = input()
    if(ans=="y"):
        print("Enter old password")
        i=3
        while(i!=0):
            enteredPass = input()
            if(cipherSuite.decrypt(password).decode()==enteredPass):
                print("enter new password")
                newPass = input()
                users[user]=cipherSuite.encrypt(password)
                p=1
                print("Password updated Successfully!!")
                break
            else:
                print("incorrect password")
            i-=1
        if(p!=1):
            print("Incorrect password attemp 3 times.Please try again later.")
    
    
    
def delete():
    print("Enter user name to delete")
    user = input()
    del users[user]
    print("User deleted Successfully")

def readAll():
    print("User Entries:")
    for key,value in users.items():
        print(key,end="\t")

def weatherInfo():
    print("Enter City Name or Longitude and Latitude in following manner: Longitude/Latitude")
    location = input()
    for info in weatherInformation[location]:
        print(info,':',weatherInformation[location][info])

def helpCmd():
    return "Press 1 for creating new user \n Press 2 to update user \n Press 3 to delete user \n Press 4 to print all users \n Press 5 for weather information \n --help for help command"
    
def Operation(argument):
    switcher = {
        1: create,
        2: update,
        3: delete,
        4: readAll,
        5: weatherInfo,
        "--help":helpCmd
    }
    func = switcher.get(argument, lambda: "Invalid")
    return func()

Choice = 0
while(Choice!="exit"):
    print("Enter your Choice:")
    print("1 - creating new user")
    print("2 - update user")
    print("3 - delete user")
    print("4 - print all users")
    print("5 - weather information")
    print("--help for help command")
    print("Type exit to quit")
    Choice = input()
    if(Choice=="--help"):
        print(Operation(Choice))
    else:
        if(Choice in ['1','2','3','4','5']):
            Operation(int(Choice))
        else:
            if(Choice=="exit"):
                break
            else:
                print("\n No Operation present on this key \n")